function moveWhite() {
	location.href = "SimpleWhiteInterior.html";
}

function moveModern() {
	location.href = "ModernBlackAndWhite.html";
}

function moveVintage() {
	location.href = "VintageStyleTone.html";
}

function moveWoody() {
	location.href = "WoodyInterior.html";
}